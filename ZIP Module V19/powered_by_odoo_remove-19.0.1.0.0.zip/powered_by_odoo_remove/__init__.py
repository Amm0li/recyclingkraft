# Copyright © 2025 TugIT. All rights reserved.
# License: LGPL-3 (see LICENSE file for details)
